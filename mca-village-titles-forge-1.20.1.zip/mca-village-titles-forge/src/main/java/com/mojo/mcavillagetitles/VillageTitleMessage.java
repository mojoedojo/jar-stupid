package com.mojo.mcavillagetitles;

import net.minecraft.network.FriendlyByteBuf;

/** Server -> client: "you just entered village X in dimension Y". */
public record VillageTitleMessage(String villageName, String dimensionId) {
    public static void encode(VillageTitleMessage m, FriendlyByteBuf buf) {
        buf.writeUtf(m.villageName, 256);
        buf.writeUtf(m.dimensionId, 256);
    }

    public static VillageTitleMessage decode(FriendlyByteBuf buf) {
        return new VillageTitleMessage(buf.readUtf(256), buf.readUtf(256));
    }
}
