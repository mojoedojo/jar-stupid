package com.mojo.mcavillagetitles;

import forge.net.conczin.mca.server.world.data.Village;
import forge.net.conczin.mca.server.world.data.VillageManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

@Mod(McaVillageTitles.MOD_ID)
public class McaVillageTitles {
    public static final String MOD_ID = "mcavillagetitles";
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    /** How often (ticks) we check where each player is. */
    private static final int CHECK_INTERVAL = 20;
    /** Don't re-announce the same village within this many ticks (stops flicker on the border). */
    private static final long REANNOUNCE_COOLDOWN = 20L * 30;

    private record Seen(String dimension, int villageId) {}

    private final Map<UUID, Seen> current = new HashMap<>();
    private final Map<UUID, Long> lastShown = new HashMap<>();
    private final Map<UUID, Seen> lastShownWhat = new HashMap<>();

    public McaVillageTitles() {
        CHANNEL.registerMessage(0, VillageTitleMessage.class,
                VillageTitleMessage::encode, VillageTitleMessage::decode, McaVillageTitles::handle);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private static void handle(VillageTitleMessage msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.onTitle(msg)));
        ctx.get().setPacketHandled(true);
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.getTickCount() % CHECK_INTERVAL != 0) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!(player.level() instanceof ServerLevel level)) continue;
            String dim = level.dimension().location().toString();

            Optional<Village> found = VillageManager.get(level)
                    .findNearestVillage(player)
                    .filter(Village::isVillage)
                    .filter(v -> v.isWithinBorder(player));

            Seen now = found.map(v -> new Seen(dim, v.getId())).orElse(null);
            Seen before = current.get(player.getUUID());
            if (Objects.equals(now, before)) continue;

            if (now == null) current.remove(player.getUUID());
            else current.put(player.getUUID(), now);
            if (now == null) continue;

            long t = server.getTickCount();
            Long last = lastShown.get(player.getUUID());
            if (now.equals(lastShownWhat.get(player.getUUID())) && last != null && t - last < REANNOUNCE_COOLDOWN) continue;

            lastShown.put(player.getUUID(), t);
            lastShownWhat.put(player.getUUID(), now);
            String name = found.get().getName();
            if (name == null || name.isBlank()) name = "Unnamed Village";
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new VillageTitleMessage(name, dim));
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        current.remove(id);
        lastShown.remove(id);
        lastShownWhat.remove(id);
    }
}
