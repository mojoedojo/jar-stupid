package com.mojo.mcavillagetitles;

/** Indirection so the dedicated server never loads client-only classes. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void onTitle(VillageTitleMessage msg) {
        VillageTitleOverlay.show(msg.villageName(), msg.dimensionId());
    }
}
