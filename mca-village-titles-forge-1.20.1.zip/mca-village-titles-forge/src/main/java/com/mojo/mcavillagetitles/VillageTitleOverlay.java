package com.mojo.mcavillagetitles;

import com.mojo.mcavillagetitles.McaVillageTitles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.fml.ModList;

import java.util.Locale;

/**
 * Draws the banner:
 *   ✦ NEW SETTLEMENT ✦
 *   Willowbrook
 *   A Village in the Overworld
 */
public final class VillageTitleOverlay {
    private static final int FADE_IN = 15, STAY = 70, FADE_OUT = 25;
    private static final int TOTAL = FADE_IN + STAY + FADE_OUT;

    private static String name = "", dimension = "";
    private static int age = TOTAL; // >= TOTAL means "not showing"

    private VillageTitleOverlay() {}

    public static void show(String villageName, String dimensionId) {
        name = villageName;
        dimension = prettyDimension(dimensionId);
        age = 0;
    }

    public static void tick() {
        if (age < TOTAL) age++;
    }

    public static void render(GuiGraphics g, float partial, int w, int h) {
        if (age >= TOTAL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;

        float t = age + partial;
        float a = t < FADE_IN ? t / FADE_IN
                : t < FADE_IN + STAY ? 1f
                : 1f - (t - FADE_IN - STAY) / FADE_OUT;
        int alpha = (int) (Math.max(0f, Math.min(1f, a)) * 255);
        if (alpha <= 8) return; // very low alpha is treated as opaque by the text renderer

        Font font = mc.font;
        // Traveler's Titles draws its biome banner in the upper-middle; sit below it if it's installed.
        int top = h / 4 + (ModList.get().isLoaded("travelerstitles") ? 62 : 0);

        int gold = (alpha << 24) | 0xFFD75E;
        int white = (alpha << 24) | 0xFFFFFF;
        int grey = (alpha << 24) | 0xC8C8C8;

        line(g, font, "✦ NEW SETTLEMENT ✦", w / 2, top, 1.0f, gold);
        line(g, font, name, w / 2, top + 14, 3.0f, white);
        line(g, font, "A Village in " + dimension, w / 2, top + 14 + 32, 1.0f, grey);
    }

    private static void line(GuiGraphics g, Font font, String text, int cx, int y, float scale, int color) {
        FormattedCharSequence seq = Component.literal(text).getVisualOrderText();
        int tw = font.width(seq);
        g.pose().pushPose();
        g.pose().translate(cx - tw * scale / 2f, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, seq, 0, 0, color, true);
        g.pose().popPose();
    }

    private static String prettyDimension(String id) {
        String path = id.contains(":") ? id.substring(id.indexOf(':') + 1) : id;
        return switch (id) {
            case "minecraft:overworld" -> "the Overworld";
            case "minecraft:the_nether" -> "the Nether";
            case "minecraft:the_end" -> "the End";
            default -> {
                StringBuilder sb = new StringBuilder("the ");
                for (String part : path.split("[_/]")) {
                    if (part.isEmpty()) continue;
                    sb.append(part.substring(0, 1).toUpperCase(Locale.ROOT)).append(part.substring(1)).append(' ');
                }
                yield sb.toString().trim();
            }
        };
    }
}
