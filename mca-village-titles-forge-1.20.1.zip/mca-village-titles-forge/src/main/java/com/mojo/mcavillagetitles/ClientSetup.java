package com.mojo.mcavillagetitles;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ClientSetup {
    private ClientSetup() {}

    @Mod.EventBusSubscriber(modid = McaVillageTitles.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void registerOverlay(RegisterGuiOverlaysEvent event) {
            event.registerAboveAll("village_title",
                    (gui, graphics, partialTick, width, height) -> VillageTitleOverlay.render(graphics, partialTick, width, height));
        }
    }

    @Mod.EventBusSubscriber(modid = McaVillageTitles.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void onTick(TickEvent.ClientTickEvent event) {
            if (event.phase == TickEvent.Phase.END) VillageTitleOverlay.tick();
        }
    }
}
